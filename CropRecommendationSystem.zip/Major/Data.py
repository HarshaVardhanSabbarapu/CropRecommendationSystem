# from flask import Flask, request, render_template
#
# app = Flask(__name__)
#
# @app.route('/')
# def index():
#     return render_template('form.html')
#
# @app.route('/submit', methods=['POST'])
# def submit():
#     if request.method == 'POST':
#         form_data = request.form
#         name = form_data['name']
#         email = form_data['email']
#         print(f"Name: {name}, Email: {email}")
#         return "Form submitted successfully"
#
# if __name__ == '__main__':
#     app.run(debug=True)
from flask import Flask, request, render_template

app = Flask(__name__)

# List to store form submissions
form_submissions = []

@app.route('/')
def index():
    return render_template('form.html')

@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        form_data = request.form
        name = form_data['name']
        email = form_data['email']
        # Store the form data in a dictionary
        submission = {'name': name, 'email': email}
        form_submissions.append(submission)  # Add the submission to the list
        return "Form submitted successfully"

@app.route('/submissions')
def view_submissions():
    # Display the submitted form data
    return render_template('submissions.html', submissions=form_submissions)

if __name__ == '__main__':
    app.run(debug=True)
